This is the folder of scrapy and some part of analysis method

The "player" folder is the python scrapy package and it contains:
Player Information
Player Performance
Club Information
Manager Information
Injury Information

The "goalinfo" folder is the python scrapy package and it contains:
Player goal information

The file "performance.py" contains the method that our team measure the performance

The file "similarity.py" contains the method for calculating the similarity function. 
