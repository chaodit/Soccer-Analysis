This is the folder of javascript of D3 visualisation. Each folder is consist with the webpage menu.


1.Web Menu:Overall Factors

"overall_factor" folder contains the javascript and html files for "Injury","Manager Age Gap","Manager nationality Sim","Player Avg Age","Player nationality Div" pages.


2.Web Menu:Relevance
“relevance” folder contains the javascript and html files for

3.Web Menu:Premier League Goals

"goal_analysis" folder contains the javascript and html files for "Club & Goals","Expenditure","Goal Type","Golden Partner","Market Value","Player Avg Height" pages.

4.Web Menu:Premier League Conceded Goals

"conceded_goal" folder contains the javascript and html files for "Overall Comparison","Season 15/16","Season 16/17","Season 17/18"