This is the folder of data cleaning. 

The "Combine_FliterData.py" deal with the three seasons personal data, combine all three season data in one file and import it to MongDB.

The "Goal_details.py" deal with the three seasons players' performance about goal detail data.

The subfolder of data is the json files which contain the data that needs to be cleaned.


