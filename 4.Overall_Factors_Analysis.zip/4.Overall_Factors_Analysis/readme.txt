This is the folder of overall factors analysis:

1."factors" folder:

The analysis python files contains:
	1.Analysis_Age.py
	2.Analysis_Height.py
	3.Analysis_Injury_Type.py
	4.Analysis_Manager_Similarity.py
	5.Analysis_National_Diversity.py
	6.Analysis_Player_Personal.py
	7.Ipynb_importer.py

The data in the json file is pre-processed, and in each python file, you need to code the correct file path when reading the json file.

2. The "performance" folder:

The file "performance.py" contains the method that our team measure the performance

The file "similarity.py" contains the method for calculating the similarity function. 
